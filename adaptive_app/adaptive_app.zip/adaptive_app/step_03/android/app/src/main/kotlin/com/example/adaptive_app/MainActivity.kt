package com.example.adaptive_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
