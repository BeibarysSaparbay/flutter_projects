package com.example.google_tracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
