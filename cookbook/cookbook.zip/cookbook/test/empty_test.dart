import 'package:flutter_test/flutter_test.dart';

void main() {
  test('totally pointless test', () {
    // totally pointless test so that CI stops bothering me.
  });
}
