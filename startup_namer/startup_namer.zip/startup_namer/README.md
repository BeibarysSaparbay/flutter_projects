This example is used by three codelabs.

Folders 1 through 4:

- https://codelabs.developers.google.com/codelabs/first-flutter-app-pt1
- https://flutter.io/docs/get-started/codelab

Folders 5 through 8:

- https://codelabs.developers.google.com/codelabs/first-flutter-app-pt2
(This codelab doesn't live on flutter.dev.)
